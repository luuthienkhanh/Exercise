#include <stdlib.h>

int sumOf(int a, int b);

int main()
{
	
	int *array = malloc(10);
	int a = 1000;
	int b = 2000;
	
	sumOf(a,b);

	return 0;
}

int sumOf(int a, int b)
{
	return (a + b);
}


