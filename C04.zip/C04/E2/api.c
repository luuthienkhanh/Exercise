#include "api.h"
//Define the functions in api.h


//Off all the LEDs
void offLED(void){
*PORTM6 &= 0x00;
*PORT6 |=0xFF;
*PORTM4 &= 0x02;
*PORT4 |=0xFF;
*PORTM10 &=0xFD;
*PORT10 |=0xFF;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 |=0xFF;

}

//On all the LEDs
void onLED(void){
*PORTM6 &=0x00;
*PORT6 &=0x00;
*PORTM4 &=0x02;
*PORT4 &=0x00;
*PORTM10 &=0xFD;
*PORT10 &=0xFD;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 &=0xFB;

}

//Wait for M mili-second:
//Refer to the description of the exercise
//to see how to write this function
void wait(unsigned long M)
{
unsigned long i = M*1778;
while (i!=0) i--;
}