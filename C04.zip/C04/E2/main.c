#pragma sfr
#include "api.h"

volatile unsigned long WAIT_TIME = 1000; //1000 m-seconds

void main()
{
while(1U){
onLED();
if (P7.6==0){WAIT_TIME=500;}//SWITCH 1
else if (P7.4==0){WAIT_TIME=2000;}//SWITCH 2
else if (P7.5==0){WAIT_TIME=1000;}//SWITCH 3
wait(WAIT_TIME);
offLED();
if (P7.6==0){WAIT_TIME=500;}//SWITCH 1
else if (P7.4==0){WAIT_TIME=2000;}//SWITCH 2
else if (P7.5==0){WAIT_TIME=1000;}//SWITCH 3
wait(WAIT_TIME);
}
}



