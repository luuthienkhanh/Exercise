#include "api.h"

void R_IT_Create(void)
{
    RTCEN   = 1U;       /* supply timer clock      */
    ITMC    = 0x0FFFU;       /* disable timer operation */
    ITMK    = 1U;       /* disable timer interrupt */
    ITIF    = 0U;       /* clear timer interrupt flag */

    OSMC    = 0x10U;    /* Select clock source: Low-speed on-chip oscillator clock */

    ITMC    = 0x00A5U; /* Configure timer data register */
}

void R_IT_Start(void)
{
    ITMC    = ITMC | 0x8000; /* enable timer operation     */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMK    = 0U;       /* enable timer interrupt     */
}

void R_IT_Stop(void)
{
    ITMK    = 1U;       /* disable timer interrupt    */
    ITIF    = 0U;       /* clear timer interrupt flag */
    ITMC    = ITMC & 0x7FFF;  /* disable timer operation    */
}

void offLED(void){
*PORTM6 &= 0x00;
*PORT6 |=0xFF;
*PORTM4 &= 0x02;
*PORT4 |=0xFF;
*PORTM10 &=0xFD;
*PORT10 |=0xFF;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 |=0xFF;

}

//On all the LEDs
void onLED(void){
*PORTM6 &=0x00;
*PORT6 &=0x00;
*PORTM4 &=0x02;
*PORT4 &=0x00;
*PORTM10 &=0xFD;
*PORT10 &=0xFD;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 &=0xFB;

}

void onBOM(void){
*PORTM4 &=0xFD;
 *PORT4 &=0xFD;
}

