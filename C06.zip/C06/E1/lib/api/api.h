#ifndef API_H
#define API_H

#include "r_macro.h"  /* System macro and standard type definition */
#include "ports.h"
void onLED(void);
void offLED(void);
void onBOM(void);

#endif