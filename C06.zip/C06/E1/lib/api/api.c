#include "api.h"

void offLED(void){
*PORTM6 &= 0x00;
*PORT6 |=0xFF;
*PORTM4 &= 0x02;
*PORT4 |=0xFF;
*PORTM10 &=0xFD;
*PORT10 |=0xFF;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 |=0xFF;

}

//On all the LEDs
void onLED(void){
*PORTM6 &=0x00;
*PORT6 &=0x00;
*PORTM4 &=0x02;
*PORT4 &=0x00;
*PORTM10 &=0xFD;
*PORT10 &=0xFD;
*PORT15_AD |=0x01;
*PORTM15 &=0xFB;
*PORT15 &=0xFB;

}

void onBOM(void){
	*PORTM4 &=0xFD;
        *PORT4 &=0xFD;
}
	