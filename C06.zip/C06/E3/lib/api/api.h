#ifndef API_H
#define API_H
#include "ports.h"
#include "r_macro.h"  /* System macro and standard type definition */

void R_TAU0_Create(void);
void R_TAU0_Start(void);
void R_TAU0_Stop(void);
//Off all the LEDs
void offLED(void);
//On all the LEDs
void onLED(void);
void onBOM(void);

#endif