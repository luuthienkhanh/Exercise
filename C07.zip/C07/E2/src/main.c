/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 03.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
//#include "lcd.h"      /* LCD driver interface */
#include "api.h" /*API for this exercise*/
#include <string.h>
#include "Glyph_API.h"      /* LCD driver interface */

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
//unsigned int second = 0;
volatile int G_elapsedTime = 0;   // Timer Counter
char * string[2];
//char * string_shown_on_lcd[10];
void main(void)
{
	/* Initialize user system */
	r_main_userinit();

	//char second='00';
	

	
	/* Clear LCD display */
	//ClearLCD();
	
	
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)

{
        uint16_t i;
        T_glyphHandle hlcd;
	T_glyphError  result;
	unsigned int second = 0;
 
       
	//char*string2="2";
//	char*string2 ="test2";
	G_elapsedTime = 0;
	/* Enable interrupt */
	EI();
	

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	
	result = GlyphOpen (&hlcd, 0);       // /* Open the Glyph API */
	result = GlyphNormalScreen(hlcd);   /* Sets up the normal LCD Screen */
	result = GlyphClearScreen(hlcd);    /* Clears the LCD Screen */
	result = GlyphSetXY(hlcd, 0, 0);        /* Set writing position to (0, 0) */
	
	R_IT_Create();
	
	R_IT_Start();

	//DisplayLCD(LCD_LINE1, "10s Time out");
	
	while ( second <100) 
	{       
		if (ITIF == 1U){
			G_elapsedTime = G_elapsedTime+1;
			if (G_elapsedTime==20){
				G_elapsedTime=0;
				if (second==99){
					second=0;
					sprintf(string, "00", second);
					//sprintf(string_shown_on_lcd, "00");
					result = GlyphSetXY(hlcd, 40, 28);
					result=GlyphString(hlcd, (void*)string, strlen(string));  /* Display the string */
				}
					else if (second<=8) {
					result = GlyphClearScreen(hlcd);
					second = second+1;
					sprintf(string, "0%d", second);
					result = GlyphSetXY(hlcd, 40, 28);
					result=GlyphString(hlcd, (void*)string, strlen(string));  /* Display the string */
					}else 
					 { result = GlyphClearScreen(hlcd);
					second = second+1;
					sprintf(string, "%d", second);
					result = GlyphSetXY(hlcd, 40, 28);
					result=GlyphString(hlcd, (void*)string, strlen(string));  /* Display the string */
			}
		}
	
			
		
	}
	}
		
	
	R_IT_Stop();

}

/******************************************************************************
End of file
******************************************************************************/

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    //G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
