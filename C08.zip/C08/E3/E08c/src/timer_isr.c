/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer_isr.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/
#pragma interrupt INTIT timer_isr//

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"    /* Timer driver interface */
#include "lcd.h"      /* LCD driver interface */
/******************************************************************************
Typedef definitions
******************************************************************************/
volatile int G_elapsedTime = 0; 
/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
//unsigned int s = 0;
//unsigned int m = 0;
//unsigned int h = 0;
char * string_shown_on_lcd[8];
extern time_t time;

/******************************************************************************
* Function Name: timer_isr
* Description  : Interval timer interrupt service routine
*              : TODO: Complete the program
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt void timer_isr(void)
{
	int a;
	a=0;
	EI();
        G_elapsedTime++;
	if (G_elapsedTime == 10){
		G_elapsedTime=0;
		time.second=time.second+1;
		if (time.second==60){
			time.second=0;
			time.minute=time.minute+1;
			if (time.minute==60){
			time.minute=0;
			time.hour=time.hour+1;
			if (time.hour==24){
				time.hour=0;}
			}
		}
	}
	//||(time.minute<=8)||(time.hour<=8)
	if (time.second<=9){
	sprintf(string_shown_on_lcd, "%d%d:%d%d:%d%d",a,time.hour,a,time.minute,a,time.second);
	DisplayLCD(LCD_LINE3, string_shown_on_lcd);
	}else if ( time.second>9&&time.minute<=9){
	        sprintf(string_shown_on_lcd, "%d%d:%d%d:%d",a,time.hour,a,time.minute,time.second);
	        DisplayLCD(LCD_LINE3, string_shown_on_lcd);
	        }else if ( time.second>9&&time.minute>9&&time.hour<=9){
			 sprintf(string_shown_on_lcd, "%d%d:%d:%d",a,time.hour,time.minute,time.second);
	                DisplayLCD(LCD_LINE3, string_shown_on_lcd);
		}else { sprintf(string_shown_on_lcd, "%d:%d:%d",time.hour,time.minute,time.second);
	                DisplayLCD(LCD_LINE3, string_shown_on_lcd);
		}
}

/******************************************************************************
End of file
******************************************************************************/

