/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : intp_isr.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 17.09.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"  /* System macro and standard type definition */

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define LED15 P4_bit.no1
#define LED_ON  (0)
#define LED_OFF (1)

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
* Function Name: intp8_isr
* Description  : Interrupt service routine for INTP8 (SW2)
*              : TODO: Complete the program  
* Arguments    : none
* Return Value : none
******************************************************************************/
//SW2
__interrupt void intp8_isr(void)
{
	/* Write your program here */
	EI();
	if (LED15==LED_ON){
		LED15=LED_OFF;
	}
	while(1){
	}
}


/******************************************************************************
* Function Name: intp9_isr
* Description  : Interrupt service routine for INTP9 (SW3)
*              : TODO: Complete the program  
* Arguments    : none
* Return Value : none
******************************************************************************/
//SW3
__interrupt void intp9_isr(void)
{
	/* Implement your program here */
	EI();
	LED15=LED_ON;
	while(1){
	}
}

/******************************************************************************
* Function Name: intp10_isr
* Description  : Interrupt service routine for INTP10 (SW1)
*              : TODO: Complete the program  
* Arguments    : none
* Return Value : none
******************************************************************************/
//SW10
__interrupt void intp10_isr(void)
{
	/* Implement your program here */
	int i;
	int j;
	EI();
	LED15=LED_ON;

	/* Wait for more than 5 second */
	for (i = 0; i < 2000; i++)
	{
		for (j = 0; j < 10000; j++)
		{
			NOP();
		}
	}
        LED15=LED_OFF;
	/* Implement your program here */
}

/******************************************************************************
End of file
******************************************************************************/

