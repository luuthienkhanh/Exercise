/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "lcd.h"
#include "r_spi_if.h" 
#include "WatchdogTimer.h"
#include "Port.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
extern unsigned int WDGFlag;

/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
  unsigned char LucSwitch = 0;
  unsigned char LucLastSwitch = 0;
  unsigned int LuiTimerCount = 0;
  
  /* Initialize LCD module*/
  R_SPI_Init(SPI_LCD_CHANNEL);
  
  /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
  R_SPI_SslInit(
  SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
  (unsigned char *)&P14,   /* Select Port register */
  (unsigned char *)&PM14,  /* Select Port mode register */
  5,                       /* Select pin index in the port */
  0,                       /* Configure CS pin active state, 0 means active LOW level  */
  0                        /* Configure CS pin active mode, 0 means active per transfer */
  );

  /* Initialize Port for LED control */
  PortInit();

  /* Initialize LCD driver */
  InitialiseLCD();

  /* Initialize WDG interrupt */
  WDGSetting();

  /* Restart the WDT counter */
  ResetWDG();

  /* Enable global interrupt */
  EI();

  /* Display information on the debug LCD. */
  DisplayLCD(LCD_LINE1, (const uint8_t *)"Press any");
  DisplayLCD(LCD_LINE2, (const uint8_t *)"button to");
  DisplayLCD(LCD_LINE3, (const uint8_t *)"access");
  DisplayLCD(LCD_LINE4, (const uint8_t *)"endless-loop");
  
  while(WDGFlag == 0);
  ResetWDG();
  
  /* Halt program in an infinite while loop */
  while (1U)
  {
      /* Reset WDG when 75% interrupt occur */
      if (WDGFlag != 0)
      {
      ResetWDG();
      WDGFlag = 0;
      }

    //SW1=P76; SW2=74; SW3=75
    /* Check if button 1 are pressed */
    if ((P7&0x40) != 0x40)
    {
      /* Show notification message */
      DisplayLCD(LCD_LINE5, (const uint8_t *)"Enter loop");
      /* Enter endless loop */
      while(1);
 
    }
    /*Press button 2 for data other than activation value is written to the WDTE register*/
    if ((P7&0x10) != 0x10)
    {
     DisplayLCD(LCD_LINE5, (const uint8_t *)"Reset");
     WDTE = 0xA0U;
    }
    
    
  }
}
